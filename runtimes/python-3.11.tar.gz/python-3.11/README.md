# Python 3.11 Basic Runtime

A lightweight Python runtime optimized for agentic AI, utility scripts, and fast startup times.

## 📊 Runtime Overview

| Attribute | Value |
|-----------|-------|
| **Name** | `python-3.11` |
| **Python Version** | 3.10.12 (host-compatible) |
| **Size** | 64.2MB |
| **Startup Time** | ~1 second |
| **Use Cases** | Agentic AI, utility scripts, lightweight jobs |

## 🎯 Perfect For

### **Agentic AI Applications**
- AI agents that need basic Python functionality
- Scripts that don't require heavy ML libraries
- Fast execution for decision-making processes
- HTTP requests and API interactions

### **Utility Scripts**
- Data processing without ML requirements
- Workflow orchestration scripts
- Configuration management
- File system operations

### **Job-Based Operations**
- Quick Python jobs with minimal overhead
- Batch processing scripts
- System monitoring tools
- Integration scripts

## 📦 Included Packages

### **Core Python Modules**
- `json` - JSON processing
- `os` - Operating system interface
- `sys` - System-specific parameters
- `math` - Mathematical functions
- `datetime` - Date and time handling
- `urllib` - URL handling modules
- `http` - HTTP modules

### **Essential External Packages**
- `requests` - HTTP library for humans
- `urllib3` - HTTP client library
- `certifi` - Certificate validation
- `charset-normalizer` - Character encoding detection
- `idna` - Internationalized domain names
- `setuptools` - Package installation tools
- `wheel` - Wheel format support

## 🚀 Installation

```bash
# Install the runtime
rnx runtime install python-3.11

# Verify installation
rnx runtime list
```

## 💡 Usage Examples

### **Basic Python Operations**
```bash
# Check Python version
rnx run --runtime=python-3.11 python --version

# Test basic functionality
rnx run --runtime=python-3.11 python -c "
import json
import os
print('✅ Basic Python working!')
print('Python path entries:', len(os.sys.path))
"
```

### **HTTP Requests** (Note: requests package needs fixes)
```bash
# The requests package is installed but may need dependency fixes
# Use urllib for HTTP requests instead:
rnx run --runtime=python-3.11 python -c "
import urllib.request
import json

try:
    response = urllib.request.urlopen('https://httpbin.org/json')
    data = json.loads(response.read())
    print('✅ HTTP request successful')
except Exception as e:
    print('Network request example (would work with internet access)')
"
```

### **File Operations**
```bash
# File processing example
rnx run --runtime=python-3.11 python -c "
import json
import tempfile

# Create temporary data
data = {'agent_id': 'ai-001', 'status': 'ready', 'tasks': [1, 2, 3]}

# Write to temp file
with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
    json.dump(data, f)
    temp_path = f.name

# Read back
with open(temp_path, 'r') as f:
    result = json.load(f)

print('✅ File operations working')
print('Agent data:', result)
"
```

### **Workflow Integration**
```yaml
# Example workflow using python-3.11 runtime
version: 1
jobs:
  ai-agent-task:
    runtime: python-3.11
    command: python3
    args: ["-c", "
import json
import sys

# Simple AI agent logic
task_data = {'task': 'process_data', 'priority': 'high'}
print(json.dumps(task_data))
print('✅ AI agent task completed', file=sys.stderr)
"]
```

## 🔄 Comparison with ML Runtime

| Feature | `python-3.11` | `python-3.11-ml` |
|---------|---------------|-------------------|
| **Size** | 64MB | 579MB |
| **Startup** | ~1 second | ~3 seconds |
| **NumPy** | ❌ | ✅ (v2.2.6) |
| **Pandas** | ❌ | ✅ (v2.3.2) |
| **Requests** | ⚠️ (needs fixes) | ✅ |
| **Use Case** | Lightweight AI, utilities | ML workloads, data science |

## 🏗️ Architecture

### **Isolation Model**
- **Complete filesystem isolation** using mount namespaces
- **Process isolation** with separate PID namespace
- **Resource limits** for CPU, memory, I/O
- **Network isolation** with custom networking support

### **Installation Process**
1. Copy host Python binaries (Python 3.10.12)
2. Create isolated library structure
3. Install essential packages in system environment
4. Copy packages to isolated runtime
5. Configure environment variables and paths

### **Directory Structure**
```
/opt/joblet/runtimes/python-3.11/
├── isolated/
│   ├── usr/bin/          # Python executables
│   ├── usr/lib/python3.10/  # Python standard library
│   ├── usr/local/lib/python3.11/site-packages/  # Installed packages
│   └── etc/              # Configuration files
└── runtime.yml           # Runtime configuration
```

## 🔧 Environment Variables

The runtime sets these environment variables:

```bash
PYTHON_HOME="/usr/local"
PATH="/usr/local/bin:/usr/bin:/bin"
PYTHONPATH="/usr/local/lib/python3.11/site-packages:/usr/lib/python3.10/site-packages"
PYTHONUNBUFFERED="1"
```

## ⚡ Performance

### **Benchmarks**
- **Cold start**: ~1 second
- **Import time** (`import json`): <10ms
- **Basic operations**: Native Python speed
- **Memory footprint**: ~20MB baseline

### **Optimization**
- No heavy ML libraries to load
- Minimal package set reduces I/O overhead
- Host-compatible Python version for performance
- Optimized for job-based execution patterns

## 🐛 Known Issues & Workarounds

### **Requests Package Dependencies**
The `requests` package is installed but may fail due to missing `six` package dependencies.

**Workaround**: Use `urllib` instead:
```python
import urllib.request
import json

# Instead of requests.get()
response = urllib.request.urlopen(url)
data = json.loads(response.read())
```

### **Package Installation**
This runtime is designed for essential functionality only. For additional packages, use `python-3.11-ml` runtime.

## 🎯 Best Practices

### **When to Use**
- ✅ AI agents needing basic Python functionality
- ✅ Utility scripts and automation
- ✅ Quick data processing without ML
- ✅ Fast startup required
- ✅ Resource-constrained environments

### **When NOT to Use**
- ❌ Machine learning workloads
- ❌ Data science with NumPy/Pandas
- ❌ Complex HTTP client requirements
- ❌ Scientific computing

### **Optimization Tips**
1. **Keep scripts lightweight** - avoid importing unnecessary modules
2. **Use built-in modules** when possible (`json`, `os`, `sys`)
3. **Prefer `urllib` over `requests`** for HTTP operations
4. **Cache results** between job runs when possible

## 📚 Related Documentation

- [Python 3.11 ML Runtime](../python-3.11-ml/README.md) - Full ML stack
- [Runtime Comparison Guide](../README.md) - All available runtimes
- [Joblet Examples](../../examples/python/) - Python usage examples
- [Workflow Examples](../../examples/workflows/) - Integration examples

---

*This runtime is optimized for Joblet's core use cases: agentic AI, HPC programming, and job-based operations.*